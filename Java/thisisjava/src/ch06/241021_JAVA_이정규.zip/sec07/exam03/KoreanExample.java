package ch06.sec07.exam03;

public class KoreanExample {

	public static void main(String[] args) {
		
		Korean k1 = new Korean ("심남희", "011001-1234567");
		System.out.println("k1 nation : " + k1.nation);
		System.out.println("k1 name : " + k1.name);
		System.out.println("k1 ssn : " + k1.ssn);
		System.out.println();
	}

}
