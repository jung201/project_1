package ch06.sec07.exam01;

public class Car {
	
	Car(String model, String color, int maxSpeed) {
		
	}

}
